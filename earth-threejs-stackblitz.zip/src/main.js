// Phase 1 main.js — three.js first-person prototype (StackBlitz)
import * as THREE from 'three';
import { PointerLockControls } from 'three/examples/jsm/controls/PointerLockControls.js';
import { ImprovedNoise } from 'three/examples/jsm/math/ImprovedNoise.js';

const container = document.getElementById('container');
const statusEl = document.getElementById('status');

// Renderer
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.shadowMap.enabled = true;
renderer.outputEncoding = THREE.sRGBEncoding;
container.appendChild(renderer.domElement);

// Scene & camera
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x87ceeb); // sky blue
scene.fog = new THREE.Fog(0x87ceeb, 300, 1200);

const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 5000);

// Lights
const hemi = new THREE.HemisphereLight(0xbfeaff, 0x556655, 0.7);
scene.add(hemi);

const sun = new THREE.DirectionalLight(0xffffff, 1.0);
sun.position.set(200, 400, 100);
sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048);
sun.shadow.camera.left = -500;
sun.shadow.camera.right = 500;
sun.shadow.camera.top = 500;
sun.shadow.camera.bottom = -500;
sun.shadow.camera.near = 0.5;
sun.shadow.camera.far = 1500;
scene.add(sun);

// Simple water plane (flat lake at y = 0)
const waterMat = new THREE.MeshStandardMaterial({ color: 0x2f6fbf, roughness: 0.6, metalness: 0.0, transparent: true, opacity: 0.9 });
const water = new THREE.Mesh(new THREE.PlaneGeometry(2000, 2000), waterMat);
water.rotation.x = -Math.PI / 2;
water.position.y = 0.0;
water.receiveShadow = true;
scene.add(water);

// Terrain parameters
const TERRAIN_SIZE = 800;
const SEGMENTS = 196; // should be even
const HEIGHT_AMPLITUDE = 20;
const noiseScale = 0.008; // tweak for smoother/rougher terrain

// Create terrain geometry
const geometry = new THREE.PlaneGeometry(TERRAIN_SIZE, TERRAIN_SIZE, SEGMENTS, SEGMENTS);
geometry.rotateX(-Math.PI / 2);

// Fill heights using ImprovedNoise
const perlin = new ImprovedNoise();
const posAttr = geometry.attributes.position;
for (let i = 0; i < posAttr.count; i++) {
  const vx = posAttr.getX(i);
  const vz = posAttr.getZ(i);
  // sample noise using same scale for the sampling function
  const y = perlin.noise(vx * noiseScale, vz * noiseScale, 0) * HEIGHT_AMPLITUDE
          + perlin.noise(vx * noiseScale * 2.5, vz * noiseScale * 2.5, 100) * (HEIGHT_AMPLITUDE * 0.4);
  posAttr.setY(i, y);
}
geometry.computeVertexNormals();

// Terrain material
const terrainMat = new THREE.MeshStandardMaterial({
  color: 0x3a7c2a,
  roughness: 1.0,
  metalness: 0.0,
  flatShading: false,
});
const terrain = new THREE.Mesh(geometry, terrainMat);
terrain.receiveShadow = true;
terrain.castShadow = false;
scene.add(terrain);

// Helper: function to get height at an arbitrary (x,z) using the same noise function
function getHeightAt(x, z) {
  const half = TERRAIN_SIZE / 2;
  if (x < -half || x > half || z < -half || z > half) return 0; // outside terrain -> sea level
  const y = perlin.noise(x * noiseScale, z * noiseScale, 0) * HEIGHT_AMPLITUDE
          + perlin.noise(x * noiseScale * 2.5, z * noiseScale * 2.5, 100) * (HEIGHT_AMPLITUDE * 0.4);
  return y;
}

// Instanced grass
const grassCount = 1600;
const grassGeom = new THREE.PlaneGeometry(0.8, 1.4);
grassGeom.translate(0, 0.7, 0); // pivot at base
const grassMat = new THREE.MeshStandardMaterial({ color: 0x3bb32b, side: THREE.DoubleSide });
const grassInstanced = new THREE.InstancedMesh(grassGeom, grassMat, grassCount);
grassInstanced.castShadow = true;
grassInstanced.receiveShadow = false;
const dummy = new THREE.Object3D();
for (let i = 0; i < grassCount; i++) {
  const x = (Math.random() - 0.5) * TERRAIN_SIZE;
  const z = (Math.random() - 0.5) * TERRAIN_SIZE;
  const y = getHeightAt(x, z);
  dummy.position.set(x, y + 0.05, z);
  dummy.rotation.y = Math.random() * Math.PI;
  const s = 0.6 + Math.random() * 0.8;
  dummy.scale.set(s, s, s);
  dummy.updateMatrix();
  grassInstanced.setMatrixAt(i, dummy.matrix);
}
scene.add(grassInstanced);

// Simple tree generator (small cones & trunks)
function createTree() {
  const trunkGeo = new THREE.CylinderGeometry(0.16, 0.16, 1.2, 6);
  const trunkMat = new THREE.MeshStandardMaterial({ color: 0x5b3a21 });
  const trunk = new THREE.Mesh(trunkGeo, trunkMat);
  trunk.castShadow = true;
  trunk.receiveShadow = false;

  const leavesGeo = new THREE.ConeGeometry(0.9, 2.0, 8);
  const leavesMat = new THREE.MeshStandardMaterial({ color: 0x1b6b1b });
  const leaves = new THREE.Mesh(leavesGeo, leavesMat);
  leaves.position.y = 1.3;
  leaves.castShadow = true;

  const group = new THREE.Group();
  trunk.position.y = 0.6;
  group.add(trunk);
  group.add(leaves);
  return group;
}

// scatter a modest number of large trees
const treeCount = 60;
for (let i = 0; i < treeCount; i++) {
  const t = createTree();
  const x = (Math.random() - 0.5) * TERRAIN_SIZE * 0.85;
  const z = (Math.random() - 0.5) * TERRAIN_SIZE * 0.85;
  const y = getHeightAt(x, z);
  if (y < 1 && Math.random() > 0.2) continue;
  t.position.set(x, y, z);
  t.scale.setScalar(0.9 + Math.random() * 1.2);
  t.rotateY(Math.random() * Math.PI * 2);
  scene.add(t);
}

// Player controls: PointerLockControls
const controls = new PointerLockControls(camera, renderer.domElement);
const onClickToLock = () => {
  controls.lock();
};
renderer.domElement.addEventListener('click', onClickToLock);

controls.addEventListener('lock', () => {
  statusEl.textContent = 'Status: Playing — Click pointer + WASD to move, Shift to run';
});
controls.addEventListener('unlock', () => {
  statusEl.textContent = 'Status: Click to begin';
});

// Movement state
const move = { forward: false, backward: false, left: false, right: false, sprint: false };
document.addEventListener('keydown', (e) => {
  if (e.code === 'KeyW') move.forward = true;
  if (e.code === 'KeyS') move.backward = true;
  if (e.code === 'KeyA') move.left = true;
  if (e.code === 'KeyD') move.right = true;
  if (e.key === 'Shift') move.sprint = true;
});
document.addEventListener('keyup', (e) => {
  if (e.code === 'KeyW') move.forward = false;
  if (e.code === 'KeyS') move.backward = false;
  if (e.code === 'KeyA') move.left = false;
  if (e.code === 'KeyD') move.right = false;
  if (e.key === 'Shift') move.sprint = false;
});

// Set initial player position above terrain center
controls.getObject().position.set(0, getHeightAt(0,0) + 1.6, 0);
scene.add(controls.getObject());

// Movement parameters
const walkSpeed = 6; // meters / second
const runMultiplier = 1.8;
const velocity = new THREE.Vector3();
const tempVec = new THREE.Vector3();
const clock = new THREE.Clock();

// animate loop
function animate() {
  requestAnimationFrame(animate);
  const delta = Math.min(0.05, clock.getDelta()); // clamp delta to avoid huge jumps

  // Movement direction based on camera orientation
  let speed = walkSpeed * (move.sprint ? runMultiplier : 1.0);

  tempVec.set(0, 0, 0);
  const forward = new THREE.Vector3();
  camera.getWorldDirection(forward);
  forward.y = 0;
  forward.normalize();

  const right = new THREE.Vector3();
  right.crossVectors(camera.up, forward).normalize(); // camera.up is (0,1,0)

  if (move.forward) tempVec.add(forward);
  if (move.backward) tempVec.sub(forward);
  if (move.left) tempVec.add(right);
  if (move.right) tempVec.sub(right);

  if (tempVec.lengthSq() > 0) {
    tempVec.normalize();
    // smooth acceleration
    velocity.lerp(tempVec.multiplyScalar(speed), 10 * delta);
  } else {
    // decay to zero
    velocity.lerp(new THREE.Vector3(0,0,0), 10 * delta);
  }

  // apply movement to the controls object
  controls.getObject().position.addScaledVector(velocity, delta);

  // keep player above ground
  const px = controls.getObject().position.x;
  const pz = controls.getObject().position.z;
  const groundY = getHeightAt(px, pz);

  const desiredY = groundY + 1.6; // eye height above ground
  controls.getObject().position.y = desiredY;

  // prevent falling through water (sea level is y=0)
  if (controls.getObject().position.y < 0.6) controls.getObject().position.y = 0.6;

  // update sun position slowly for a tiny feel of time passing (optional)
  const t = performance.now() * 0.00005;
  sun.position.x = Math.cos(t) * 400;
  sun.position.y = 350 + Math.sin(t) * 50;
  sun.position.z = Math.sin(t) * 300;

  renderer.render(scene, camera);
}
animate();

// Resize handler
window.addEventListener('resize', () => {
  renderer.setSize(window.innerWidth, window.innerHeight);
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
});
