Phase 1 — Earth → Space (three.js) — StackBlitz import

This zip contains a Vite-based three.js project prepared for StackBlitz or CodeSandbox.

How to run on StackBlitz:
1. Open https://stackblitz.com/
2. Click 'Create Project' -> 'Upload Project' (or use the Import/Upload feature)
3. Upload the zip file you downloaded from this page.
4. Wait for dependencies to install (three will be installed automatically).
5. Open the preview. If pointer-lock/mouse look doesn't work inside the embedded preview, click 'Open in New Window' in the preview toolbar to run in a new tab.

Notes:
- Controls: Click the preview and press mouse to lock pointer. WASD to move. Shift to run.
- If performance is slow, open src/main.js and reduce grassCount and treeCount variables.

